// SpaceSails canvas renderer (M2). Pure screen-space 2D canvas wrapper: this module knows nothing
// about world meters or the camera — it only decodes the opcode command buffer that
// SpaceSails.Client.Rendering.CanvasRenderer batches in C# and paints it with Canvas2D.
//
// Exports consumed from C# via [JSImport] (SpaceSails.Client/Rendering/RendererInterop.cs):
//   initCanvas(canvasId), startLoop(canvasId), stopLoop(canvasId),
//   drawFrame(canvasId, buffer, length), drawTexts(canvasId, json)
//
// Calls back into C# via the assembly's [JSExport]ed RendererInterop.Tick / .OnResize, obtained
// through the runtime's getAssemblyExports (see ensureExports below) — this module owns the
// requestAnimationFrame loop, not C#.

const OP_POLYLINE = 1;
const OP_CIRCLE = 2;
const OP_POLYGON = 3;
const OP_IMAGE = 4;
const OP_IMAGE_SLICE = 5;

/** @type {Map<string, { canvas: HTMLCanvasElement, ctx: CanvasRenderingContext2D, rafId: number|null, running: boolean }>} */
const canvases = new Map();

// Raster image cache, keyed by the integer id C# assigns in CanvasRenderer.RegisterImage. The
// float command buffer can only carry an id + dest rect, so the decoded bitmap must live here.
/** @type {Map<number, HTMLImageElement>} */
const images = new Map();

// Preload an image by id (C# → JS via RendererInterop.LoadImage). Decodes asynchronously; an
// OP_IMAGE draw before it finishes simply skips (img.complete is false) and starts painting once
// the browser has it. Idempotent per id.
export function loadImage(id, url) {
    if (images.has(id)) {
        return;
    }
    const img = new Image();
    img.decoding = 'async';
    img.src = url;
    images.set(id, img);
}

let exportsPromise = null;

async function ensureExports() {
    exportsPromise ??= (async () => {
        const { getAssemblyExports } = await globalThis.getDotnetRuntime(0);
        const exports = await getAssemblyExports('SpaceSails.Client.dll');
        return exports.SpaceSails.Client.Rendering.RendererInterop;
    })();
    return exportsPromise;
}

function reportSize(entry, canvasId) {
    const rect = entry.canvas.getBoundingClientRect();
    ensureExports().then((rendererInterop) => rendererInterop.OnResize(rect.width, rect.height));
}

export function initCanvas(canvasId, observeResize) {
    const canvas = /** @type {HTMLCanvasElement} */ (document.getElementById(canvasId));
    if (!canvas) {
        throw new Error(`renderer.js: no canvas element with id "${canvasId}"`);
    }

    const ctx = canvas.getContext('2d');
    const entry = { canvas, ctx, rafId: null, running: false };
    canvases.set(canvasId, entry);

    // Secondary canvases (the scope inset) must NOT report their size: OnResize feeds the
    // main map viewport, and a 280px inset would shrink the whole world.
    if (observeResize) {
        const observer = new ResizeObserver(() => reportSize(entry, canvasId));
        observer.observe(canvas);
        reportSize(entry, canvasId);
    }
}

export function drawFrame(canvasId, buffer, length) {
    const entry = canvases.get(canvasId);
    if (!entry) {
        return;
    }

    // `buffer` is a short-lived MemoryView over the C# command buffer, reinterpreted as bytes on the
    // C# side (source-generated JS interop only supports MemoryView<byte>, not MemoryView<float> —
    // see RendererInterop.DrawFrame). Copy it out once (cheap — 500 polylines is a few thousand
    // floats) since the view is only valid for the duration of this call, then reinterpret those
    // bytes as the Float32Array `length` says they are.
    const bytes = buffer.slice();
    const view = new Float32Array(bytes.buffer, bytes.byteOffset, length);
    const { canvas, ctx } = entry;

    const widthPx = view[0] | 0;
    const heightPx = view[1] | 0;
    if (canvas.width !== widthPx || canvas.height !== heightPx) {
        canvas.width = widthPx;
        canvas.height = heightPx;
    }

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = rgba(view[2], view[3], view[4], view[5]);
    ctx.fillRect(0, 0, widthPx, heightPx);

    let i = 6;
    while (i < length) {
        const op = view[i++];

        if (op === OP_POLYLINE) {
            const r = view[i++], g = view[i++], b = view[i++], a = view[i++];
            const lineWidth = view[i++];
            const n = view[i++] | 0;

            // One stroke() per polyline is deliberate: trajectory ribbons are drawn translucent, and
            // per-polyline stroking lets overlapping paths accumulate opacity (denser = more traffic).
            // Merging same-styled polylines into a single path would flatten that and change the look.
            ctx.beginPath();
            for (let p = 0; p < n; p++) {
                const x = view[i++], y = view[i++];
                if (p === 0) {
                    ctx.moveTo(x, y);
                } else {
                    ctx.lineTo(x, y);
                }
            }
            ctx.strokeStyle = rgba(r, g, b, a);
            ctx.lineWidth = lineWidth;
            ctx.stroke();
        } else if (op === OP_POLYGON) {
            // Closed, optionally-filled polygon (SundaySecondPlan PR-B): trade-lane areas and
            // scan wedges. Same fill/stroke header shape as OP_CIRCLE, then a point list.
            const hasFill = view[i++];
            const fr = view[i++], fg = view[i++], fb = view[i++], fa = view[i++];
            const sr = view[i++], sg = view[i++], sb = view[i++], sa = view[i++];
            const strokeWidth = view[i++];
            const n = view[i++] | 0;

            ctx.beginPath();
            for (let p = 0; p < n; p++) {
                const x = view[i++], y = view[i++];
                if (p === 0) {
                    ctx.moveTo(x, y);
                } else {
                    ctx.lineTo(x, y);
                }
            }
            ctx.closePath();
            if (hasFill) {
                ctx.fillStyle = rgba(fr, fg, fb, fa);
                ctx.fill();
            }
            if (strokeWidth > 0) {
                ctx.strokeStyle = rgba(sr, sg, sb, sa);
                ctx.lineWidth = strokeWidth;
                ctx.stroke();
            }
        } else if (op === OP_CIRCLE) {
            const hasFill = view[i++];
            const fr = view[i++], fg = view[i++], fb = view[i++], fa = view[i++];
            const sr = view[i++], sg = view[i++], sb = view[i++], sa = view[i++];
            const strokeWidth = view[i++];
            const x = view[i++], y = view[i++], radius = view[i++];

            ctx.beginPath();
            ctx.arc(x, y, Math.max(radius, 0), 0, Math.PI * 2);
            if (hasFill) {
                ctx.fillStyle = rgba(fr, fg, fb, fa);
                ctx.fill();
            }
            if (strokeWidth > 0) {
                ctx.strokeStyle = rgba(sr, sg, sb, sa);
                ctx.lineWidth = strokeWidth;
                ctx.stroke();
            }
        } else if (op === OP_IMAGE) {
            // Raster backdrop / texture: id + dest rect + alpha. drawImage confines the bitmap to
            // the rect (it cannot bleed past it), so room backdrops stay inside their room.
            const id = view[i++] | 0;
            const x = view[i++], y = view[i++], w = view[i++], h = view[i++], alpha = view[i++];
            const img = images.get(id);
            if (img && img.complete && img.naturalWidth > 0) {
                const prevAlpha = ctx.globalAlpha;
                ctx.globalAlpha = Math.max(0, Math.min(1, alpha));
                ctx.drawImage(img, x, y, w, h);
                ctx.globalAlpha = prevAlpha;
            }
        } else if (op === OP_IMAGE_SLICE) {
            // Textured raycaster column: id + NORMALIZED source rect (0..1) + dest rect + alpha. The
            // source fractions are multiplied by the decoded bitmap's natural size here, so C# never
            // needs the texture's pixel dimensions. sw is clamped to >= 1px so a thin vertical strip
            // still samples a real texel column.
            const id = view[i++] | 0;
            const sxf = view[i++], syf = view[i++], swf = view[i++], shf = view[i++];
            const dx = view[i++], dy = view[i++], dw = view[i++], dh = view[i++], alpha = view[i++];
            const img = images.get(id);
            if (img && img.complete && img.naturalWidth > 0 && dh > 0) {
                const nw = img.naturalWidth, nh = img.naturalHeight;
                const sx = sxf * nw, sy = syf * nh;
                const sw = Math.max(1, swf * nw), sh = Math.max(1, shf * nh);
                const prevAlpha = ctx.globalAlpha;
                ctx.globalAlpha = Math.max(0, Math.min(1, alpha));
                ctx.drawImage(img, sx, sy, sw, sh, dx, dy, dw, dh);
                ctx.globalAlpha = prevAlpha;
            }
        } else {
            // Unknown opcode: stop rather than looping forever on a corrupted buffer.
            break;
        }
    }
}

export function drawTexts(canvasId, json) {
    const entry = canvases.get(canvasId);
    if (!entry) {
        return;
    }

    const texts = JSON.parse(json);
    const { ctx } = entry;
    for (const t of texts) {
        ctx.fillStyle = rgba(t.r, t.g, t.b, t.a);
        ctx.font = t.font;
        ctx.textAlign = t.align;
        ctx.textBaseline = 'alphabetic';
        ctx.fillText(t.text, t.x, t.y);
    }
}

export async function startLoop(canvasId) {
    const entry = canvases.get(canvasId);
    if (!entry) {
        return;
    }

    entry.running = true;
    const rendererInterop = await ensureExports();

    const frame = (timestampMs) => {
        if (!entry.running) {
            return;
        }
        rendererInterop.Tick(timestampMs);
        entry.rafId = requestAnimationFrame(frame);
    };
    entry.rafId = requestAnimationFrame(frame);

    // Browsers suspend requestAnimationFrame entirely for hidden documents (tab switched,
    // window occluded, machine locked), which would silently freeze the whole simulation —
    // warp time stops passing the moment the player looks away. While hidden, tick from a
    // 1 Hz interval instead (background timers are throttled to about that anyway); rendering
    // to an invisible canvas is wasted but 1 Hz of it is free, and C#'s accumulator clamp
    // already bounds the per-tick work. Timestamps stay on the performance.now() clock either
    // way, so the C# dt math never sees a seam.
    entry.hiddenTimerId = setInterval(() => {
        if (entry.running && document.visibilityState === 'hidden') {
            rendererInterop.Tick(performance.now());
        }
    }, 1000);
}

export function stopLoop(canvasId) {
    const entry = canvases.get(canvasId);
    if (!entry) {
        return;
    }

    entry.running = false;
    if (entry.rafId !== null) {
        cancelAnimationFrame(entry.rafId);
        entry.rafId = null;
    }
    if (entry.hiddenTimerId) {
        clearInterval(entry.hiddenTimerId);
        entry.hiddenTimerId = null;
    }
}

// ─── #1244 · THE RATION ON THE BOOT'S OWN TIMERS, TAKEN OFF FOR THE LENGTH OF THE BOOT ────────────
//
// The staged boot (#1114/#1203) hands the frame back between every slice of work, and it does so on a
// browser TIMER: `Task.Delay(1)` from C#, which #318 chose over `Task.Yield` precisely BECAUSE it parks
// on one. Chrome rations a hidden document's timers to roughly one a second, so the ~90-slice boot that
// costs two seconds in front of a captain cost ninety behind one — measured live, #1244:
// `freighter 1 of 8 — 1086 ms, 989, 860, 998, 991, 1002…`. The slices were never slow. The yield was.
//
// WHY A PROMISE-SHAPED YIELD IS NOT THE ANSWER, though it is the obvious one. A `MessageChannel` message
// is a task rather than a timer and nothing rations it — but awaiting one from C# does not help, because
// the .NET WASM runtime resumes EVERY continuation through `globalThis.setTimeout` too (grep the shipped
// `dotnet.runtime.*.js`: `safeSetTimeout(mono_wasm_schedule_timer_tick, …)`, and not one `MessageChannel`
// in the file). Measured on this branch: a boot yielding on a port message was still 86 s hidden against
// 14 s visible, one rationed second per slice, because the tick resolved at once and the C# side then sat
// in the runtime's own clamped queue.
//
// So the seam does not change at all. What changes is the ration under it: while the boot runs and nobody
// is looking, the SHORTEST timers — 4 ms and under, which is the .NET timer queue's "as soon as you can",
// and nothing a human or an animation ever asks for — are served on a message tick instead. Every other
// timer on the page is untouched, the swap is put back the moment the boot ends (or is abandoned), and
// the game's own hidden-tab heartbeat above (`setInterval(…, 1000)`) is well clear of the threshold.
const SHORTEST_TIMER_MS = 4;
const tickTimers = new Map(); // our own tick numbers → { fn, cancelled }
let tickTimerChannel = null;
let rationedSetTimeout = null;  // the browser's own, while ours stands in for it
let rationedClearTimeout = null; // the browser's own, while our cancel wrapper stands (it outlives the swap until the ticks drain)
let nextTickTimerId = 1;

/** #1466 · THE MASTHEAD'S REAL BOTTOM, in canvas pixels, for the canvas HUD to start under. On a phone (<= 600 px)
 *  the desk tab bar wraps to up to three rows over the top of the (full-bleed) canvas, and the deck's nerve block
 *  is drawn at a fixed y, so its NERVE label sat under the bar. This is the same number keepTheMapControlsBelowTheTabBar
 *  publishes as --map-control-top (the bar's bottom, plus the 4 px of air), read for the canvas. 0 when the bar is
 *  absent or the glass is not a phone, so a desktop is never moved. */
export function mastheadBottomPx() {
    if (typeof document === 'undefined' || !window.matchMedia || !window.matchMedia('(max-width: 600px)').matches) {
        return 0;
    }
    const page = document.querySelector('.map-page');
    const bar = page ? page.querySelector('.desk-tab-bar') : null;
    if (!page || !bar || !bar.isConnected) {
        return 0;
    }
    return Math.max(0, bar.getBoundingClientRect().bottom - page.getBoundingClientRect().top + 4);
}

/** Is the document hidden — this tab behind another, the window minimised or occluded, the machine
 *  locked? Read ONLY by the boot's hand-back, to decide whether its timers are being rationed. It
 *  decides nothing whatever about the world that gets built: #1244's law, held by
 *  `TheHiddenTabDecidesNothingAboutTheWorldTests`. */
export function pageIsHidden() {
    return typeof document !== 'undefined' && document.visibilityState === 'hidden';
}

/** The handle the runtime is given for a tick. An OBJECT, never a number: the browser's own timer ids are
 *  small integers from one shared list, and a number of ours would be indistinguishable from one of
 *  theirs — a native `clearTimeout(7)` could cancel OUR tick 7 (and the thread-pool pump with it), and
 *  after the swap ends a stale handle of ours handed to the browser's `clearTimeout` could cancel an
 *  unrelated native timer, the hidden-tab heartbeat among them. Truthy, so the runtime's `Xo && …` holds;
 *  inert to a native `clearTimeout`, which ignores anything that is not a number. */
function tickHandle(tick) {
    return Object.freeze({ tick });
}

/** Once the swap is off AND the last posted tick has been served or cancelled, give the browser's own
 *  `clearTimeout` back and close the channel. Until then the ticks the runtime already posted still run:
 *  dropping one would leave the runtime's "a pump is already scheduled" latch set for good, and no
 *  thread-pool continuation would ever run again. */
function finishTheDrain() {
    if (rationedSetTimeout !== null || tickTimers.size > 0 || rationedClearTimeout === null) {
        return;
    }
    globalThis.clearTimeout = rationedClearTimeout;
    rationedClearTimeout = null;
    if (tickTimerChannel !== null) {
        tickTimerChannel.port1.onmessage = null;
        tickTimerChannel.port1.close();
        tickTimerChannel = null;
    }
}

/**
 * Serve the shortest timers on a message tick (`on`), or hand the browser's own back (`off`).
 * Idempotent in both directions. Returns whether the swap is now standing, so C# can say honestly in a
 * log line whether it got what it asked for — a browser with no `MessageChannel` gets nothing and says so
 * rather than pretending. `off` puts `setTimeout` back at once, but ticks already posted are still served.
 */
export function serveTheShortestTimersOnATick(on) {
    if (on && rationedSetTimeout === null && typeof MessageChannel === 'function') {
        if (tickTimerChannel === null) {
            tickTimerChannel = new MessageChannel();
            tickTimerChannel.port1.onmessage = (e) => {
                const pending = tickTimers.get(e.data);
                tickTimers.delete(e.data);
                try {
                    if (pending && !pending.cancelled) { pending.fn(); }
                } finally {
                    finishTheDrain();
                }
            };
            tickTimerChannel.port1.start();
        }

        if (rationedClearTimeout === null) {
            rationedClearTimeout = globalThis.clearTimeout;

            // The runtime CANCELS its previous timer before scheduling the next one
            // (`Xo && clearTimeout(Xo)`), so a handle of ours has to be cancellable or a stale tick would
            // fire work the runtime had already withdrawn.
            globalThis.clearTimeout = function (id) {
                if (id !== null && typeof id === 'object') {
                    const pending = tickTimers.get(id.tick);
                    if (pending) { pending.cancelled = true; tickTimers.delete(id.tick); finishTheDrain(); }
                    return;
                }
                return rationedClearTimeout.call(globalThis, id);
            };
        }

        rationedSetTimeout = globalThis.setTimeout;

        globalThis.setTimeout = function (fn, ms, ...rest) {
            // Only the runtime's own "immediately" — and only the plain one-argument form, so a caller
            // passing arguments through to its callback keeps the timer that honours them.
            if (typeof fn !== 'function' || rest.length > 0 || (Number(ms) || 0) > SHORTEST_TIMER_MS) {
                return rationedSetTimeout.call(globalThis, fn, ms, ...rest);
            }
            const id = nextTickTimerId++;
            tickTimers.set(id, { fn, cancelled: false });
            tickTimerChannel.port2.postMessage(id);
            return tickHandle(id);
        };
    } else if (!on && rationedSetTimeout !== null) {
        globalThis.setTimeout = rationedSetTimeout;
        rationedSetTimeout = null;
        finishTheDrain();
    }
    return rationedSetTimeout !== null;
}

function rgba(r, g, b, a) {
    return `rgba(${r}, ${g}, ${b}, ${a / 255})`;
}

// ---- Audio cues (M10 polish) ----
// Tiny WebAudio blips, no assets. The context can only start after a user gesture; the cues
// are triggered by keyboard/click handlers, which qualify, and we lazily resume each call.

let audioCtx = null;

// ─── #338 addendum (owner, 2026-07-18 — THE GAME'S FIRST SOUND): the audio switch. "An audio toggle
// (default ON, remembered) so streamers and the noise-averse can mute; all future sounds hang off the
// same switch." Kept as a browser-local pref (localStorage, NOT the game vault/save) so a mute survives a
// reload without touching persistence. Every cue below early-returns when it is off. ───
const AUDIO_PREF_KEY = 'spaceSails.audioEnabled';
let audioEnabled = true;
try { audioEnabled = window.localStorage.getItem(AUDIO_PREF_KEY) !== '0'; } catch { /* default on */ }

/** The current audio-on state (so C# can sync its toggle label). */
export function getAudioEnabled() { return audioEnabled; }

/** Flip the master audio switch and remember it browser-locally. All cues + the chirp hang off this. */
export function setAudioEnabled(on) {
    audioEnabled = !!on;
    try { window.localStorage.setItem(AUDIO_PREF_KEY, audioEnabled ? '1' : '0'); } catch { /* pref is a nicety */ }
}

/** #338 addendum item 4 — WebAudio needs a user gesture before it will play, so unlock the context on the
 *  first click/keypress of the session. Then a cue fired later from the rAF loop (the first-contact chirp,
 *  which is not itself a gesture) can sound instead of being silently blocked. */
export function armAudio() {
    try {
        audioCtx ??= new AudioContext();
        if (audioCtx.state === 'suspended') { audioCtx.resume(); }
    } catch { /* audio is decoration */ }
}

const CUES = {
    rum: { type: 'triangle', freq: 392, to: 587, duration: 0.35, gain: 0.09 }, // a jaunty rising swagger for the rum locker
    pulse: { freq: 220, to: 440, duration: 0.09, gain: 0.06, type: 'square' },   // engine thump
    board: { freq: 523, to: 784, duration: 0.35, gain: 0.08, type: 'sine' },     // prize jingle rise
    fire:  { freq: 130, to: 45,  duration: 0.4,  gain: 0.12, type: 'square' },   // the driver's boom
    hit:   { freq: 660, to: 990, duration: 0.3,  gain: 0.10, type: 'triangle' }, // splash — bright ping up
    miss:  { freq: 440, to: 160, duration: 0.5,  gain: 0.07, type: 'sine' },     // round gone — sad fall
    reveal:{ freq: 587, to: 1175, duration: 0.45, gain: 0.08, type: 'sine' },    // a scan resolves it — bright discovery rise
    voidjump:{ freq: 196, to: 784, duration: 0.7, gain: 0.10, type: 'sawtooth' }, // #255 long-haul engage — a rising bottle-pop whoosh into the void
    buzzer:{ freq: 175, to: 150, duration: 0.32, gain: 0.045, type: 'square' },   // #424 THE UNEXPLAINED SIGNAL — a faint, low buzzer off-deck; quiet + muffled, no one explains it
    // #467 · BEING HURT MUST BE UNMISSABLE (owner, 2026-07-27: "I had no sound to alert that I was taking
    // damage… I should know when I'm hurt"). The generic `alarm` was shared with a dozen other things, so a
    // blow read as background in a fight. Two distinct voices instead:
    block: { freq: 1400, to: 520, duration: 0.14, gain: 0.11, type: 'square' },   // steel turns it — a hard bright CLANG
    wound: { freq: 150,  to: 42,  duration: 0.55, gain: 0.16, type: 'sawtooth' }, // it got in — low, wet and wrong
    last:  { freq: 90,   to: 70,  duration: 0.9,  gain: 0.18, type: 'sawtooth' }, // one more will do it — a floor-level dread tone
    // ─── #938 D1 · SIXTY-ONE CALL SITES THAT MADE NO SOUND. `playCue` bails silently on a name it does not
    // know (`if (!cue) { return; }` below), so five names the game has always shouted have always been mute:
    // `alarm` ×41 — every atmosphere breach, every scuttle, BUSTED, the deflection impact — plus `blip` ×11,
    // `gameover` ×5, `burn` ×2 and `door` ×2. The note above blames #467 for deleting `alarm`; the history
    // says otherwise. `git log --all -S "alarm:" -- "*.js"` returns NOTHING: these five were never defined,
    // in any commit, on any branch. The callers were written against a table that never had them, and the
    // only guard on cues (TheRedPenIsAnInstrumentTests) asserts the call is WRITTEN, never that it sounds.
    // So there is nothing to restore — and inventing five voices out of nowhere is not this house's habit
    // either. Each one below is CUT FROM THE NEAREST CUE THAT ALREADY SHIPPED and names its parent, so the
    // game keeps one palette instead of gaining five strangers.
    alarm: { freq: 880, to: 415, duration: 0.30, gain: 0.10, type: 'square' },    // `buzzer`'s square alert voice, an octave up and given the urgency the buzzer deliberately withholds — the buzzer is the one nobody explains, this is the one everybody hears
    blip:  { freq: 1046, to: 1245, duration: 0.06, gain: 0.05, type: 'square' },  // `pulse`'s short square tick, two octaves up and a third the length — a console acknowledging a keypress, not an engine
    gameover:{ freq: 220, to: 55, duration: 1.2,  gain: 0.13, type: 'sine' },     // `miss`'s sad sine fall (the round that went nowhere) dropped an octave and held two and a half times as long — the same shape at the scale of a life
    burn:  { freq: 110, to: 220, duration: 0.55, gain: 0.08, type: 'square' },    // `pulse`'s engine thump an octave down and six times longer — a burn IS the thump, sustained
    door:  { freq: 420, to: 180, duration: 0.18, gain: 0.05, type: 'sawtooth' },  // a sawtooth hiss-fall pitched into the middle — escaping air, through a seal instead of a nozzle
};

export function playCue(kind, scale = 1) {
    if (!audioEnabled) {
        return;
    }
    // #167 · NOT INTO AN EMPTY ROOM. While the document is hidden the sim does not stop — startLoop below
    // keeps ticking it off a setInterval precisely because rAF is suspended — so a tab left in the
    // background at 10,000× warp flies for hours, and every automated burn, alarm and arrival in that
    // stretch would shout at a listener who is not there, or queue up to greet them when they come back.
    // The same visibilityState the loop already reads, read once more here. Audio is decoration: nothing
    // in the game's state depends on a cue having sounded.
    if (typeof document !== 'undefined' && document.visibilityState === 'hidden') {
        return;
    }
    const cue = CUES[kind];
    if (!cue) {
        return;
    }

    // #167 · HOW BIG THE EVENT WAS, 0…1 — BurnPlume.CueScale, the same number the flame on the map is
    // sized by, so the ear and the eye cannot come to disagree about it. Length and loudness both move,
    // because a one-pulse trim and a forty-pulse orbital insertion are not the same event and must not
    // sound like it. A caller that passes nothing gets the cue exactly as its table entry was tuned.
    const size = Number.isFinite(scale) ? Math.min(Math.max(scale, 0), 1) : 1;
    const duration = cue.duration * (0.3 + (0.7 * size));
    const level = cue.gain * (0.45 + (0.55 * size));

    try {
        audioCtx ??= new AudioContext();
        if (audioCtx.state === 'suspended') {
            audioCtx.resume();
        }

        const t = audioCtx.currentTime;
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = cue.type;
        osc.frequency.setValueAtTime(cue.freq, t);
        osc.frequency.exponentialRampToValueAtTime(cue.to, t + duration);
        gain.gain.setValueAtTime(level, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + duration);
        osc.connect(gain).connect(audioCtx.destination);
        osc.start(t);
        osc.stop(t + duration);
    } catch {
        // Audio is decoration: autoplay policies or missing WebAudio must never break the game.
    }
}

/** #338 addendum — THE GAME'S FIRST SOUND: the motion tracker's first-contact chirp. Two short, quiet
 *  rising tones, radar-flavoured, no assets — the "device chirps in the holster" moment fired on the 0→N
 *  tracker edge (Core-gated in MotionTracker.StepChirp). Respects the master audio switch and the
 *  gesture-armed context, exactly like every other cue. */
export function playChirp() {
    if (!audioEnabled) {
        return;
    }
    // Not into an empty room (#167): the same hidden-tab mute playCue has — the sim keeps ticking from the
    // heartbeat and a contact in a background tab must neither chirp nor queue up for the return.
    if (typeof document !== 'undefined' && document.visibilityState === 'hidden') {
        return;
    }
    try {
        audioCtx ??= new AudioContext();
        if (audioCtx.state === 'suspended') {
            audioCtx.resume();
        }
        const t0 = audioCtx.currentTime;
        // Two quick blips, the second a step higher — a little "ping-ping" that reads as "contact".
        for (let i = 0; i < 2; i++) {
            const t = t0 + (i * 0.12);
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            const f = i === 0 ? 660 : 880;
            osc.type = 'sine';
            osc.frequency.setValueAtTime(f, t);
            osc.frequency.exponentialRampToValueAtTime(f * 1.5, t + 0.08);
            gain.gain.setValueAtTime(0.0001, t);
            gain.gain.exponentialRampToValueAtTime(0.05, t + 0.012);
            gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.10);
            osc.connect(gain).connect(audioCtx.destination);
            osc.start(t);
            osc.stop(t + 0.11);
        }
    } catch {
        // Audio is decoration: a blocked chirp must never break the sweep.
    }
}

// ─── The personal vault (#225): localStorage autosave + export/import a .json file. ───
// Kept tiny and defensive — a private-browsing localStorage throw, a storage quota, or a cancelled
// file picker must NEVER break the game; the worst case is "the save didn't take", surfaced in C#.

/** Read the vault JSON from localStorage, or null if none / storage unavailable. */
export function vaultRead(key) {
    try {
        return window.localStorage.getItem(key);
    } catch {
        return null;
    }
}

/** Write the vault JSON to localStorage. Returns true on success. */
export function vaultWrite(key, json) {
    try {
        window.localStorage.setItem(key, json);
        return true;
    } catch {
        return false; // quota or private-mode denial — C# just notes the autosave didn't land.
    }
}

/** #992 · Bring the first element matching `selector` inside its own scrollers.
 *
 *  The flight plan's step list scrolls now (the panel is bound to the window), so opening a step near the
 *  bottom of a long plan could put that step's editor below the LIST's fold — the owner's complaint one
 *  scroller further in. `block: 'nearest'` is the smallest honest motion: a step already fully in view is
 *  not moved at all, and one hanging off an edge is brought just inside it. Instant, not smooth — the
 *  editor's buttons have to be pressable the moment the row opens, and a running animation is a moving
 *  target for a captain and for a guard alike. Best-effort: a selector that matches nothing is a no-op,
 *  never a throw into the render loop. */
export function scrollIntoView(selector) {
    try {
        const el = document.querySelector(selector);
        if (el) {
            el.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'instant' });
        }
    } catch {
        // Decoration: a browser that will not scroll for us still leaves the list scrollable by hand.
    }
}

/** Put text on the clipboard — the [copy] behind the Captain's crash note. Best-effort: a browser that
 *  denies clipboard access (or an insecure origin) falls back to a hidden textarea + execCommand, and if
 *  that fails too we simply report false rather than throwing into the game. */
export function copyText(text) {
    try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            // The write is a promise and a refusal REJECTS it, after we have returned. An unhandled
            // rejection reaches index.html's black box and would overwrite the very crash note the captain
            // is copying, so the refusal is caught here and the old way is tried instead.
            navigator.clipboard.writeText(text).catch(() => { copyTheOldWay(text); });
            return true;
        }
    } catch {
        // fall through to the old way
    }
    return copyTheOldWay(text);
}

/** The hidden-textarea + execCommand copy: the fallback for an insecure origin and for a refused write. */
function copyTheOldWay(text) {
    try {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        const ok = document.execCommand('copy');
        document.body.removeChild(ta);
        return ok;
    } catch {
        return false;
    }
}

/** Forget the vault (used by a fresh start that abandons the save). */
export function vaultClear(key) {
    try {
        window.localStorage.removeItem(key);
    } catch {
        // nothing to do — a storage that can't clear also can't have saved.
    }
}

/** Download the vault as a .json file the owner can keep against a server wipe. */
export function vaultDownload(filename, json) {
    try {
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(url), 0);
    } catch {
        // A blocked download is not fatal; the localStorage autosave still holds the vault.
    }
}

/** Open a file picker and resolve the chosen .json file's text (or '' if cancelled/failed). */
export function vaultImport() {
    return new Promise((resolve) => {
        try {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = 'application/json,.json';
            input.style.display = 'none';
            document.body.appendChild(input);

            const done = (text) => {
                try { document.body.removeChild(input); } catch { /* already gone */ }
                resolve(text);
            };

            input.addEventListener('change', () => {
                const file = input.files && input.files[0];
                if (!file) { done(''); return; }
                const reader = new FileReader();
                reader.onload = () => done(typeof reader.result === 'string' ? reader.result : '');
                reader.onerror = () => done('');
                reader.readAsText(file);
            });
            // A cancel fires no 'change'; resolve empty after focus returns so the caller never hangs.
            window.addEventListener('focus', () => setTimeout(() => {
                if (!input.files || input.files.length === 0) { done(''); }
            }, 300), { once: true });

            input.click();
        } catch {
            resolve('');
        }
    });
}

// #1463 · keepTheMapControlsBelowTheTabBar. The desk tab bar WRAPS to two or three rows on a narrow glass (about
// 390-800 px), and the 🗺 Layers button and the find box are absolutely placed from --map-control-top, a typed
// one-row value. CSS cannot measure a wrap, so while the bar really has wrapped this sets --map-control-top on
// .map-page to the bar's REAL bottom, and --map-controls-on to 1 while the controls are up (the bar's bottom
// margin in ShipTabsStrip.razor.css keeps a band of that height clear under it, so the banner flows under them).
// With one row nothing is set and the stylesheet's own values stand, so a desktop's side-by-side banner is kept.
// On a phone (<= 600 px) it also publishes the masthead's real bottom as --map-masthead-bottom, which the
// desk-chip column docks under. A ResizeObserver on the bar and on the masthead catches every wrap; a childList
// observer on the page catches the controls coming and going with the desk; a slow poll catches the page itself
// arriving. When nothing is set and the bar has not wrapped, a pass does no writes at all.
(function keepTheMapControlsBelowTheTabBar() {
    if (typeof window === 'undefined' || typeof document === 'undefined' || !window.matchMedia) {
        return;
    }
    const phone = window.matchMedia('(max-width: 600px)');
    let page = null;
    let bar = null;
    let stack = null;
    let resizeWatch = null;
    let pageWatch = null;
    let queued = false;
    let wrote = false;
    const NAMES = ['--map-control-top', '--map-controls-on', '--map-masthead-bottom'];

    const clear = () => {
        if (wrote && page) {
            NAMES.forEach(n => page.style.removeProperty(n));
        }
        wrote = false;
    };
    const apply = () => {
        queued = false;
        if (!page || !page.isConnected) {
            wrote = false;
            return;
        }
        const pageTop = page.getBoundingClientRect().top;
        const first = bar ? bar.querySelector('.desk-tab') : null;
        const wrapped = !!(bar && bar.isConnected && first &&
            bar.getBoundingClientRect().height > first.getBoundingClientRect().height * 1.5);
        if (!wrapped && !phone.matches) {
            clear();
            return;
        }
        if (wrapped) {
            const top = bar.getBoundingClientRect().bottom - pageTop + 4;
            const on = page.querySelector(':scope > .map-layers, :scope > .nav-search') ? '1' : '0';
            page.style.setProperty('--map-control-top', top + 'px');
            page.style.setProperty('--map-controls-on', on);
        } else {
            page.style.removeProperty('--map-control-top');
            page.style.removeProperty('--map-controls-on');
        }
        if (phone.matches && stack) {
            page.style.setProperty('--map-masthead-bottom', (stack.getBoundingClientRect().bottom - pageTop + 4) + 'px');
        } else {
            page.style.removeProperty('--map-masthead-bottom');
        }
        wrote = true;
    };
    const queue = () => {
        if (!queued) {
            queued = true;
            requestAnimationFrame(apply);
        }
    };
    const find = () => {
        const p = document.querySelector('.map-page');
        const b = p ? p.querySelector('.desk-tab-bar') : null;
        const t = p ? p.querySelector('.map-topstack') : null;
        if (p !== page) {
            if (pageWatch) { pageWatch.disconnect(); }
            wrote = false;
            page = p;
            if (page) {
                pageWatch = new MutationObserver(queue);
                pageWatch.observe(page, { childList: true });
            }
        }
        if (b !== bar || t !== stack) {
            if (resizeWatch) { resizeWatch.disconnect(); }
            bar = b;
            stack = t;
            if (typeof ResizeObserver !== 'undefined') {
                resizeWatch = new ResizeObserver(queue);
                if (bar) { resizeWatch.observe(bar); }
                if (stack) { resizeWatch.observe(stack); }
            }
        }
        queue();
    };
    phone.addEventListener('change', find);
    window.addEventListener('resize', queue);
    setInterval(find, 500);
    find();
})();
